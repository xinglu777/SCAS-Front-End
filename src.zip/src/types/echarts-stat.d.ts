declare module 'echarts-stat' {
    export const transform: any;
}
